# -*- coding: utf-8 -*-
from dataclasses import dataclass
from typing import List, Dict, Tuple

@dataclass
class Horse:
    no: str
    name: str
    base_prob: float   # %
    odds: float
    style: str         # "逃げ","先行","差し","追込"
    wt_delta: float    # kg

def _bias_gain(surface:str, going:str, bias:str, bias_on:str, style:str)->float:
    if bias_on == "常時OFF":
        return 0.0
    pref = {"逃げ":"逃げ","先行":"先行","差し":"差し","追込":"追込","フラット":"フラット"}.get(bias,"フラット")
    if going in ("重","不良"):
        cap = 0.20; base = 0.12
    elif going=="稍重":
        cap = 0.10; base = 0.06
    else:
        cap = 0.08; base = 0.04
    strong = (going in ("重","不良")) or (bias_on=="強制ON")
    if pref=="フラット" or not strong:
        cap = min(cap, 0.08); base = min(base,0.03)
    if style==pref and pref!="フラット":
        return min(cap, base)
    elif pref!="フラット":
        opp = {"逃げ":"追込","先行":"差し","差し":"先行","追込":"逃げ"}[pref]
        if style==opp: return -min(cap, base)
        return 0.0
    return 0.0

def _weight_gain(wt_delta:float)->float:
    try: d = float(wt_delta)
    except: return 0.0
    if d >= +8: return +0.05
    if d >= +4: return +0.03
    if d <= -8: return -0.05
    if d <= -4: return -0.03
    return 0.0

def adjust_probs(surface:str, going:str, bias:str, bias_on:str, horses:List[Horse])->List[Tuple[Horse,float,float]]:
    out = []
    for h in horses:
        bg = _bias_gain(surface, going, bias, bias_on, h.style)
        wg = _weight_gain(h.wt_delta)
        adj = max(0.0, min(100.0, h.base_prob * (1.0 + bg + wg)))
        ev = (adj/100.0) * h.odds if h.odds>0 else 0.0
        out.append((h, adj, ev))
    s = sum(adj for _,adj,_ in out)
    if s>100 and s>0:
        out = [(h, adj*100.0/s, (adj*100.0/s)/100.0*h.odds) for (h,adj,_) in out]
    out.sort(key=lambda x: x[2], reverse=True)
    return out

def suggest_bets(surface:str, going:str, bias_on:str, ranking:List[Tuple[Horse,float,float]])->Dict:
    heavy_mode = (going in ("重","不良")) and (bias_on!="常時OFF")
    alloc = {"単勝":35,"ワイド":35,"馬連":20,"三連複":10} if heavy_mode else {"単勝":40,"ワイド":30,"馬連":20,"三連複":10}
    top = ranking[0][0] if ranking else None
    pairs = []
    if len(ranking)>=2: pairs.append((ranking[0][0], ranking[1][0]))
    if len(ranking)>=3: pairs.append((ranking[0][0], ranking[2][0]))
    trio = []
    if len(ranking)>=4: trio = [ranking[0][0].no] + [ranking[1][0].no, ranking[2][0].no, ranking[3][0].no]
    return {"alloc":alloc,"single":top.no if top else None,"pairs":[(a.no,b.no) for a,b in pairs],"trio":trio}

def make_post_text(venue, race, surface, going, bias, bias_on, ranking, bets):
    # 6軸の詳細根拠まではLINE簡易版では省略（将来:寄与率説明を追加）
    lines1 = [f"【{race}｜当日最終】", f"{surface}{going}×{bias}バイアス（{bias_on}）。"]
    top3 = ranking[:3]
    if top3:
        evs = "／".join([f"{r[0].no}{r[0].name}{r[2]:.2f}" for r in top3])
        lines1.append(f"EV上位：{evs}")
    lines1.append("#数値屋K")
    post1 = "\n".join(lines1)
    lines2 = ["【買い目（配分）】"]
    alloc = bets["alloc"]; single = bets["single"]; pairs=bets["pairs"]; trio=bets["trio"]
    if single: lines2.append(f"単勝：{single}（{alloc['単勝']}%）")
    if pairs:
        pair_txt = "・".join([f"{a}-{b}" for a,b in pairs])
        lines2.append(f"ワイド/馬連：{pair_txt}（{alloc['ワイド']}%/{alloc['馬連']}%）")
    if trio: lines2.append(f"三連複：{trio[0]}−{','.join(trio[1:])}（{alloc['三連複']}%）")
    lines2.append("#数値屋K")
    post2 = "\n".join(lines2)
    return post1, post2
