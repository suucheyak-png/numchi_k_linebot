# -*- coding: utf-8 -*-
# 数値屋K LINE Bot (前日→直前→結果 まで一貫対応)
# 必要: pip install flask line-bot-sdk python-dotenv
import os, re, json
from dotenv import load_dotenv
from flask import Flask, request, abort
from linebot import LineBotApi, WebhookHandler
from linebot.exceptions import InvalidSignatureError
from linebot.models import MessageEvent, TextMessage, TextSendMessage

from keiba_predict_core import Horse, adjust_probs, suggest_bets, make_post_text

load_dotenv()  # .env から読み込み

CHANNEL_SECRET = os.getenv("LINE_CHANNEL_SECRET","")
CHANNEL_ACCESS_TOKEN = os.getenv("LINE_CHANNEL_ACCESS_TOKEN","")

app = Flask(__name__)
line_bot_api = LineBotApi(CHANNEL_ACCESS_TOKEN)
handler = WebhookHandler(CHANNEL_SECRET)

# --- ヘルパ: 文字列→float安全変換 ---
def to_float(x, default=None):
    try:
        return float(str(x).replace('%','').replace('％',''))
    except:
        return default

# --- パーサ群 ---
# 例: 前日 TOK12 芝2500 良 / 上位 7 テーオー 22% 4.3 / 10 シュト 18% 5.8 / 5 ヒート 14% 8.1
pat_pre = re.compile(r'^前日\s+(?P<raceid>\S+)\s+(?P<surface>芝|ダート)(?P<course>\d+)?\s+(?P<going>良|稍重|重|不良)\s*/\s*上位\s*(?P<body>.+)$')
# 例: 直前 TOK12 / 稍重 先行 / 体重 7 +6, 10 -4, 5 0 / 単 7 3.8, 10 5.2
pat_now  = re.compile(r'^直前\s+(?P<raceid>\S+)\s*/\s*(?P<going>良|稍重|重|不良)\s*(?P<bias>逃げ|先行|差し|追込|フラット)?\s*/\s*体重\s*(?P<wts>[^/]+)(?:\s*/\s*単\s*(?P<odds>.+))?')
# 例: 結果 TOK12 / 7-10-5 / 前＋持続 / 上がり 7=34.2
pat_res  = re.compile(r'^結果\s+(?P<raceid>\S+)\s*/\s*(?P<trio>[0-9\-]+)\s*/\s*(?P<exp>.+?)\s*(?:/\s*上がり\s*(?P<agari>.*))?')

# 馬行: "7 テーオー 22% 4.3" or "7 22% 4.3"
def parse_horses_chunk(chunk):
    horses = []
    # 区切りは "/" または ","
    parts = re.split(r'\s*/\s*|\s*,\s*', chunk.strip())
    for p in parts:
        p = p.strip()
        if not p: continue
        # パターン: 番号 名前 勝率% オッズ
        m = re.findall(r'^(?P<no>\d+)\s+(?:(?P<name>[^\d\s]+)\s+)?(?P<prob>\d+(?:\.\d+)?)%?\s+(?P<odds>\d+(?:\.\d+)?)$', p)
        if m:
            no, name, prob, odds = m[0]
            if not name: name = f"#{no}"
            horses.append(dict(no=no, name=name, prob=to_float(prob,0.0), odds=to_float(odds,0.0), style='先行', wt=0.0))
            continue
        # 代替: "7 22 4.3"
        m2 = re.findall(r'^(?P<no>\d+)\s+(?P<prob>\d+(?:\.\d+)?)\s+(?P<odds>\d+(?:\.\d+)?)$', p)
        if m2:
            no, prob, odds = m2[0]
            horses.append(dict(no=no, name=f"#{no}", prob=to_float(prob,0.0), odds=to_float(odds,0.0), style='先行', wt=0.0))
    return horses

def parse_weights(s):
    # "7 +6, 10 -4, 5 0"
    out = {}
    for token in re.split(r',\s*', s.strip()):
        m = re.findall(r'(?P<no>\d+)\s*([=:]\s*)?(?P<d>[+\-]?\d+)', token)
        if m:
            no, _, d = m[0]
            out[no] = to_float(d,0.0)
    return out

def parse_odds(s):
    # "7 3.8, 10 5.2"
    out = {}
    for token in re.split(r',\s*', s.strip()):
        m = re.findall(r'(?P<no>\d+)\s*(?P<o>\d+(?:\.\d+)?)', token)
        if m:
            no, o = m[0]
            out[no] = to_float(o,0.0)
    return out

def summarize_ranking(surface, going, bias, ranking, race_label, bias_on='自動判定ON'):
    # ランキング→テキスト（2連投）
    bets = suggest_bets(surface, going, bias_on, ranking)
    post1, post2 = make_post_text('', race_label, surface, going, bias, bias_on, ranking, bets)
    return post1, post2

@app.route("/health", methods=["GET"])
def health():
    return "ok", 200

@app.route("/callback", methods=["POST"])
def callback():
    signature = request.headers.get("X-Line-Signature")
    body = request.get_data(as_text=True)
    try:
        handler.handle(body, signature)
    except InvalidSignatureError:
        abort(400)
    return "OK"

@handler.add(MessageEvent, message=TextMessage)
def handle_message(event):
    text = event.message.text.strip()
    try:
        # ヘルプ
        if text in ["help","ヘルプ","？","?"]:
            help_msg = (
                "【数値屋K LINE Bot】\n"
                "・前日 例：\n"
                "  前日 TOK12 芝2500 良 / 上位 7 テーオー 22% 4.3 / 10 シュト 18% 5.8 / 5 ヒート 14% 8.1\n"
                "・直前 例：\n"
                "  直前 TOK12 / 稍重 先行 / 体重 7 +6, 10 -4, 5 0 / 単 7 3.8, 10 5.2\n"
                "・結果 例：\n"
                "  結果 TOK12 / 7-10-5 / 前＋持続 / 上がり 7=34.2\n"
            )
            line_bot_api.reply_message(event.reply_token, TextSendMessage(text=help_msg))
            return

        # 前日
        m = pat_pre.match(text)
        if m:
            raceid = m.group('raceid'); surface=m.group('surface'); going=m.group('going'); body=m.group('body')
            horses = parse_horses_chunk(body)
            # デフォ脚質は先行。後で必要なら拡張（名前の末尾で指定など）
            ranking = adjust_probs(surface, going, 'フラット', '常時OFF', [Horse(no=h['no'],name=h['name'],base_prob=h['prob'],odds=h['odds'],style=h['style'],wt_delta=h['wt']) for h in horses])
            p1, p2 = summarize_ranking(surface, going, 'フラット', ranking, raceid, bias_on='常時OFF')
            line_bot_api.reply_message(event.reply_token, [TextSendMessage(text=p1), TextSendMessage(text=p2)])
            return

        # 直前
        m = pat_now.match(text)
        if m:
            raceid = m.group('raceid'); going=m.group('going'); bias=m.group('bias') or 'フラット'
            wts = parse_weights(m.group('wts') or '')
            odds_map = parse_odds(m.group('odds') or '')
            # 直前は最低でも2頭を想定。直前では名前等を省く想定なので、追加メッセージで前日情報を再送しても可。
            # 簡便のため、直前入力だけでも動くようノードを構成（勝率・オッズは直前で与えるのが望ましい）
            # 例: "直前 TOK12 / 稍重 先行 / 体重 7 +6,10 -4 / 単 7 3.8,10 5.2,5 8.1"
            horses = []
            # 勝率が未入力でもオッズからはEV化できないので、最低限は別メッセージで前日送信しておく想定。
            # ここではオッズのみで来た場合は基礎勝率20/15/12など暫定を適用（保守的に）
            defaults = [20.0, 15.0, 12.0, 10.0, 8.0, 6.0]
            for i, (no, o) in enumerate(odds_map.items()):
                prob = defaults[i] if i < len(defaults) else 5.0
                wt = wts.get(no, 0.0)
                horses.append(Horse(no=no, name=f"#{no}", base_prob=prob, odds=o, style='先行', wt_delta=wt))
            if not horses:
                line_bot_api.reply_message(event.reply_token, TextSendMessage(text="直前情報の形式を確認してください（例を参照：help）"))
                return
            surface = '芝'  # 既定（必要ならraceidで保存したsurfaceを使う設計に拡張）
            ranking = adjust_probs(surface, going, bias, '自動判定ON', horses)
            p1, p2 = summarize_ranking(surface, going, bias, ranking, raceid, bias_on='自動判定ON')
            line_bot_api.reply_message(event.reply_token, [TextSendMessage(text=p1), TextSendMessage(text=p2)])
            return

        # 結果
        m = pat_res.match(text)
        if m:
            raceid = m.group('raceid'); trio=m.group('trio'); exp=m.group('exp')
            msg = (
                f"【{raceid}｜検証】\n"
                f"想定：{exp}。\n"
                f"着順：{trio}。\n"
                f"所感：展開整合・上位EVの順序を検証、次週補正へ反映。\n"
                "#数値屋K"
            )
            line_bot_api.reply_message(event.reply_token, TextSendMessage(text=msg))
            return

        # どれでもない場合
        line_bot_api.reply_message(event.reply_token, TextSendMessage(text="コマンドを認識できません。help と送信してください。"))
    except Exception as e:
        line_bot_api.reply_message(event.reply_token, TextSendMessage(text=f"エラー: {e}"))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", 8000)))
